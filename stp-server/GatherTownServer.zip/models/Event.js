const mongoose = require("mongoose");
const eventSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  date: { type: Date, required: true },
  time: { type: String, required: true },
  image: { type: String },
  location: {
    // coordinates: { type: [Number], required: true },
    state: { type: String },
    city: { type: String },
    latitude: { type: Number, required: true },
    longitude: { type: Number, required: true },
    zipCode: { type: String },
    description: { type: String, required: true },
  },
});
module.exports = mongoose.model("Event", eventSchema);
