const Event = require("../models/Event");

const createEventController = (req, res) => {
  var event = new Event(req.body);
  event
    .save()
    .then(() => {
      res.status(200).json({
        message: "Event Created",
        code: 200,
      });
    })
    .catch((err) => {
      res.status(404).json({
        error: err,
        code:404
      });
    });
};

const getEventByIdController = (req, res) => {
  Event.find({ _id: req.params.id })
    .exec()
    .then((events) => {
      res.status(200).json({ code: 200, events });
    })
    .catch((e) => {
      res.status(404).json({
        error: e,
        code:404
      });
    })
    .catch((err) => {});
};

const getNearbyEventsController = (req, res) => {
  const search = req.query.search;
  const query = {
    $or: [{ "location.city": new RegExp(search, "i") }, { "location.state": new RegExp(search, "i") }, { "location.zipCode": new RegExp(search, "i") }],
  };
  Event.find(query)
    .exec()
    .then((events) => {
      res.status(200).json({ code: 200, events });
    })
    .catch((e) => {
      res.status(404).json({
        error: e,
        code:404
      });
    })
    .catch((err) => {
      console.log(err);
    });
};

module.exports = { createEventController, getNearbyEventsController, getEventByIdController };
