const express = require("express");
const api = express.Router();
const authMiddleware = require("../middleware/authMiddleware");

const { createEventController , getNearbyEventsController , getEventByIdController } = require("../controllers/eventController");

api.post("/createEvent", authMiddleware , createEventController);

api.get("/list", getNearbyEventsController);

api.get("/:id", getEventByIdController);


module.exports = api;
