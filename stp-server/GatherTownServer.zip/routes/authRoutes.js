const express = require("express");
const api = express.Router();
const authMiddleware = require("../middleware/authMiddleware");

const { signupController, signinController, forgetPasswordController, resetPasswordController } = require("../controllers/authController");



api.post("/register", signupController);

api.post("/login", signinController);

api.get("/forgetpassword/:email", forgetPasswordController);

api.post("/resetpassword", authMiddleware, resetPasswordController);

module.exports = api;
